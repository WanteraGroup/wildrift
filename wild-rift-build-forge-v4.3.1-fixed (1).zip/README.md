# WR FORGE — Wild Rift Build Builder

Saját, Lovable/Base44 nélküli React/Vite prototípus.

## Indítás
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

A jelenlegi verzió lokális demo adatkészlettel működik. Az adatmodell patch-alapú bővítésre készült; következő lépésként Supabase-be köthető champion/item/rune/patch táblákkal és külön Build Engine szabályréteggel.

A projekt nem Riot Games terméke és nincs a Riot Games által jóváhagyva.

## Patch 7.3
A UI patch intelligence panel a Riot hivatalos 7.3 patch notes alapján készült; a build engine jelenleg továbbra is lokális demo adatokkal működik. Forrás: https://wildrift.leagueoflegends.com/en-us/news/game-updates/wild-rift-patch-notes-7-3/

## V2.1 Build Engine
- Patch 7.3 champion seed: Hwei, Sylas, Rek'Sai
- Patch 7.2 champion seed: Yunara, Cho'Gath
- Patch-aware marksman item pool
- Threat-aware damage/DPS/survival/utility scoring
- Skill-order output panel

## V3 Matchup Engine
A V3 a teljes megadott enemy compositionből threat tageket képez (AP, tank, crit, assassin, heal, fighter, marksman), és ezek alapján cseréli a situational item slotokat. A rendszer determinisztikus és API-kulcs nélkül fut.

## V4 Live Data Layer
A frontend induláskor megpróbálja betölteni a Wild Rift champion adatokat és a naponta frissülő statisztikákat a `WildRift-Merged-Champion-Data` és `WildRift-Merged-Stats-Data` nyilvános endpointjairól. Hiba esetén automatikusan visszaesik a beépített demo adatokra.

## V4.1 Adaptive Item Scoring
- Strukturált matchup-mátrix champion class alapján
- Threat-tag extraction
- Item candidate scoring
- Playstyle weighting
- Dinamikus Build Score
- Pipeline státusz UI

## V4.2 Item Economy
- Item cost + base gold-efficiency réteg
- Economy-weighted item scoring
- Build cost display
- Average item efficiency display
- Item rationale in result view

## V4.3 Build Tools
- Build compare
- Matchup matrix viewer
- Copy build action
- Saved build cards

## V4.3.1
- Fixed Vite/Rolldown JSX parse error in main.jsx.
